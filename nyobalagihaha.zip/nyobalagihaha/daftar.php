<!DOCTYPE html>
<html>
<head>
  <title>Daftar Kursus</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" type="text/css" href="./bootstrap4/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="style.css">
  <script type="text/javascript" href="bootstrap4/js/bootstrap.js"></script>
  <link rel="icon" href="">
</head>
<body style="background-color: #d2b08c">
  <?php 
    include 'koneksi.php';
   ?>
   <div class = "container" margin-top="20px">
    <div class="row">
      <div class="col-sm-6">
        <img src="img/poster.jpg" class="border border-1 border-white phone shadow p-3">
      </div>

      <div class="col-sm-6">
        <div class="right-column text-center">
        <img src="img/logola.png"class="instagram-logo">
          <p class="or">DAFTAR</p>
          <form method="post">
            <div class="form-group">
              <input type="text" class="form-control" data-validation="email" placeholder="E-mail" name="email">
            </div>
            <div class="form-group">
              <input type="password" class="form-control" data-validation="length" data-validation-length="min8" placeholder="Kata Sandi" name="password">
            </div>
            <div class="form-group">
              <input type="text" class="form-control" placeholder="Nama Lengkap" name="nama">
            </div>
            <div class="form-group">
              <input type="text" class="form-control" placeholder="Nomor HP" name="no_hp">
            </div>
            <div class="form-group">
              <input type="text" class="form-control" placeholder="Usia" name="usia">
            </div>
            <div class="form-group">
              <input type="text" class="form-control" placeholder="Alamat" name="alamat">
            </div>
           <div class="form-group">
              <input type="radio" class="form-check-label-input" name="paket" value="Shining">
              <label class="form-check-label">Shining</label>
              <input type="radio" class="form-check-label-input" name="paket" value="Shimmering">
              <label class="form-check-label">Shimmering</label>
              <br>
              <input type="radio" class="form-check-label-input" name="paket" value="Splendid">
              <label class="form-check-label">Splendid</label>     
            </div>
            <button type="submit" class="btn btn-primary btn-block" name="daftar">Submit</button>
          </form>
          <p class="terms">Dengan mendaftar, Anda telah memahami dan menyetujui <b><a href="persyaratan.php" target="_blank">Persyaratan</a></b> kursus.</p>
        </div>
          <div class="pb-2 right-column-login text-center" id="punya">
          <p>Sudah mendaftar?<a href="login.php"> Login disini</a></p>  
          </div>
      </div>
    </div>
  </div>
     <?php
  if(isset($_POST['daftar'])){
    if ($_POST['email']=="" || $_POST['password']=="" || $_POST['nama']=="" || $_POST['usia']=="" || $_POST['no_hp']=="" || $_POST['alamat']=="" | $_POST['paket']=="") {
      echo '<script language="javascript">
      alert ("Semua kolom harus diisi!");
      window.location="daftar.php";
      </script>';
    }
    else{
    include 'koneksi.php';
    $cek_user=mysqli_query($koneksi,"SELECT * FROM user WHERE email='$_POST[email]'");
    if(mysqli_num_rows($cek_user)!=null) {
      echo '<script language="javascript">
      alert ("Email Sudah Ada Yang Menggunakan");
      window.location="daftar.php";
      </script>';
      exit();
    }
    else {
      $password=$_POST['password'];
      $password=md5($password);
      mysqli_query($koneksi,"INSERT INTO user (tipe_user,email, password) VALUES ('2','$_POST[email]','$password')");
      $id=mysqli_query($koneksi,"SELECT id_user from user where email='$_POST[email]'");
      $data=mysqli_fetch_object($id);
      mysqli_query($koneksi,"INSERT INTO murid (id_user, nama, usia, no_hp, alamat,paket)
        VALUES ('$data->id_user','$_POST[nama]','$_POST[usia]', '$_POST[no_hp]','$_POST[alamat]','$_POST[paket]')");

      echo '<script language="javascript">
      alert ("Registrasi Berhasil Di Lakukan!");
      window.location="login.php";
      </script>';
      exit();
    }
  }
}
  ?>
 

  <script src="js/jquery-3.3.1.min.js"></script>
  <script src="js/jquery.form-validator.min.js"></script>
  <script src="js/main.js"></script>
</body>
</html>