-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 26 Nov 2019 pada 07.07
-- Versi server: 10.4.6-MariaDB
-- Versi PHP: 7.3.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kursusmusik`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `admin`
--

CREATE TABLE `admin` (
  `nama_admin` char(15) DEFAULT NULL,
  `id_user` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `admin`
--

INSERT INTO `admin` (`nama_admin`, `id_user`) VALUES
('Salsa', 1),
('Ayola', 2);

-- --------------------------------------------------------

--
-- Struktur dari tabel `murid`
--

CREATE TABLE `murid` (
  `nama` char(30) DEFAULT NULL,
  `usia` int(3) DEFAULT NULL,
  `no_hp` varchar(12) DEFAULT NULL,
  `id_user` int(10) DEFAULT NULL,
  `paket` varchar(10) DEFAULT NULL,
  `alamat` varchar(60) DEFAULT NULL,
  `verifikasi` varchar(1) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `murid`
--

INSERT INTO `murid` (`nama`, `usia`, `no_hp`, `id_user`, `paket`, `alamat`, `verifikasi`) VALUES
('Briananda Rizaldi', 19, '08287388789', 31, 'Shining', 'Bandung', '1'),
('Ika Arihta', 14, '0831838274', 32, 'Shining', 'Padang', '1'),
('Emily Kang', 16, '085760998877', 34, 'Shimmering', 'Yogyakarta', '0'),
('Ari', 15, '081228139695', 37, 'Shining', 'Yogyakarta', '1');

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE `user` (
  `tipe_user` varchar(1) DEFAULT NULL,
  `id_user` int(10) NOT NULL,
  `email` varchar(50) DEFAULT NULL,
  `password` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`tipe_user`, `id_user`, `email`, `password`) VALUES
('1', 1, 'salsagatha@gmail.com', 'salsa5'),
('1', 2, 'ayolaika@gmail.com', 'ayola'),
('2', 31, 'malamtakbrian@gmail.com', 'e03ae33ee8417ce2c9785274217636e0'),
('2', 32, 'ika@gmail.com', '4e4d6c332b6fe62a63afe56171fd3725'),
('2', 34, 'emilykang@gmail.com', 'e9f5713dec55d727bb35392cec6190ce'),
('2', 37, 'ari@gmail.com', 'e03ae33ee8417ce2c9785274217636e0');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `admin`
--
ALTER TABLE `admin`
  ADD KEY `fkiduser` (`id_user`);

--
-- Indeks untuk tabel `murid`
--
ALTER TABLE `murid`
  ADD KEY `fkiduser2` (`id_user`);

--
-- Indeks untuk tabel `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id_user`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `email_2` (`email`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `user`
--
ALTER TABLE `user`
  MODIFY `id_user` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `admin`
--
ALTER TABLE `admin`
  ADD CONSTRAINT `fkiduser` FOREIGN KEY (`id_user`) REFERENCES `user` (`id_user`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `murid`
--
ALTER TABLE `murid`
  ADD CONSTRAINT `fkiduser2` FOREIGN KEY (`id_user`) REFERENCES `user` (`id_user`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
