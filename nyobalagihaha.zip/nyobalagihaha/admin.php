<!DOCTYPE html>
<html>
<head>
	<title>Menu Admin</title>
	<link rel="stylesheet" type="text/css" href="bootstrap4/css/bootstrap.min.css">
	<script type="text/javascript" href="bootstrap4/js/bootstrap.min.js"></script>
</head>
<body>
	<?php 
	error_reporting(0);
	session_start();
	include 'cek_session.php';
	include 'koneksi.php';

	$sql=mysqli_query($koneksi,"SELECT id_user,nama,usia,no_hp,alamat,paket,verifikasi from murid");
	?>
		<nav class="p-2 navbar bg-dark text-light">
		<div class="col-6">
		<h3>Admin Mode</h3>	
		</div>
		<div class="col-6 text-right">
		<h4>Selamat Datang, <?php echo "$_SESSION[nama]"; ?></h4>
		<a href="logout.php"><button>LOG OUT</button></a>	
		</div>
	</nav>
	<div class="container">
		<div class="row mt-3">
			<table class="table table-bordered">
				<thead class="thead-dark">
					<th>ID Murid</th>
					<th>Nama Murid</th>
					<th>Usia</th>
					<th>Nomor HP</th>
					<th>Alamat</th>
					<th>Paket</th>
					<th>Action</th>
				</thead>
				<tbody>
					<?php 
					while ($data=mysqli_fetch_object($sql)) {
					 ?>
					 <tr>
					 <td><?php echo "$data->id_user"; ?></td>
					 <td><?php echo "$data->nama"; ?></td>
					 <td><?php echo "$data->usia"; ?></td>
					 <td><?php echo "$data->no_hp";?></td>
					 <td><?php echo "$data->alamat"; ?></td>
					 <td><?php paket ($data); ?></td>
					 <td>
					 	<?php
					 	if($data->verifikasi==0){
					 		echo "<form method='post' action='admin.php'><br>	 	
					 			<button class='btn btn-outline-success' name='verif' value='$data->id_user'>Verifikasi</button></form>";
					 	}
					 	?>
					 	<form method="post" action="admin.php"><br>
					 			<button class="btn btn-outline-danger" name="hapus" value="<?= $data->id_user ?>">Hapus Data</button></form>
					 			<br>
					 </td>
					 </tr>
					 <?php 
						}

				if(isset($_POST['verif'])){
					$sql=mysqli_query($koneksi,"UPDATE murid SET verifikasi='1' WHERE id_user='$_POST[verif]'");
					header("refresh:0.2");
				}
				else if(isset($_POST['hapus'])){
					$id=$_POST['hapus'];
					$sql=mysqli_query($koneksi,"SELECT * from murid where id_user='$id'");
					$data=mysqli_fetch_object($sql);
					mysqli_query($koneksi,"DELETE from murid where id_user='$id'");
					mysqli_query($koneksi,"DELETE from user where id_user='$id'");
				}
				function paket($data){
					if($data->paket=='Shining'){
						echo "Shining";
					}
					elseif($data->paket=='Shimmering'){
						echo "Shimmering";
					}
					else{
						echo "Splendid";
					}
			}
					  ?>
				</tbody>
			</table>
		</div>
	</div>
</body>
</html>