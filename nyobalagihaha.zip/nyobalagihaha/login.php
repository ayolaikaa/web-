<!DOCTYPE html>
<html lang="en">
<head>
	<title>Login Kursus</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/iconic/css/material-design-iconic-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->
</head>
<body>
	
	
	<div class="container-login100" style="background-image: url('images/bg-01.jpg');">
		<div class="wrap-login100 p-l-55 p-r-55 p-t-80 p-b-30">
			<form method="POST" class="login100-form validate-form">
				<span class="login100-form-title p-b-37">
					Sign In
				</span>

				<div class="wrap-input100 validate-input m-b-20" data-validate="Enter email">
					<input class="input100" type="text" name="email" placeholder="email">
					<span class="focus-input100"></span>
				</div>

				<div class="wrap-input100 validate-input m-b-25" data-validate = "Enter password">
					<input class="input100" type="password" name="password" placeholder="password">
					<span class="focus-input100"></span>
				</div>

				<div class="container-login100-form-btn">
					<button class="login100-form-btn" name="login">
						Sign In
					</button>
				</div>
			</form>
<?php 
	if(isset($_POST['login'])){
		session_start();
		include 'koneksi.php';
		$email=$_POST['email'];
		$password=$_POST['password'];
		$password2=md5($password);
		
		$sql=mysqli_query($koneksi,"SELECT * from user where email='$email' and (password='$password' or password='$password2')");
		$row=mysqli_num_rows($sql);
		if ($row==1) {
			$data=mysqli_fetch_object($sql);
			if($data->tipe_user==1){
				$id=$data->id_user;
				$nama=mysqli_query($koneksi,"SELECT nama_admin from admin where id_user='$id'");
				$data=mysqli_fetch_object($nama);
				$_SESSION['nama']=$data->nama_admin;
				$_SESSION['login']=true;
				echo '<script language="javascript">
			window.location="admin.php";
			</script>';
			}
			else{
				$id=$data->id_user;
				$nama=mysqli_query($koneksi,"SELECT nama from murid where id_user='$id'");
				$data=mysqli_fetch_object($nama);
				$_SESSION['login']=true;
				$_SESSION['nama']=$data->nama;
				$_SESSION['id_user']=$id;
				echo '<script language="javascript">
			alert ("Login Berhasil!");
			window.location="nyobamenu.php";
			</script>';
			}
		}
		else{
			echo '<script language="javascript">
			alert ("Login gagal!");
			window.location="login.php";
			</script>';
	}
}
	?>
			
<!--===============================================================================================-->
	<script src="vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/animsition/js/animsition.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/bootstrap/js/popper.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/daterangepicker/moment.min.js"></script>
	<script src="vendor/daterangepicker/daterangepicker.js"></script>
<!--===============================================================================================-->
	<script src="vendor/countdowntime/countdowntime.js"></script>
<!--===============================================================================================-->
	<script src="js/main.js"></script>

</body>
</html>