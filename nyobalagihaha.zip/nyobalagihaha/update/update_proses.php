<?php 
include '../koneksi.php';
$id=$_POST['id'];
$nama=$_POST['nama'];
$usia=$_POST['usia'];
$no_hp=$_POST['no_hp'];
$alamat=$_POST['alamat'];
$paket=$_POST['paket'];

	if ($_POST['email']=="" || $_POST['password']=="" || $_POST['nama']=="" || $_POST['usia']=="" || $_POST['no_hp']=="" || $_POST['alamat']=="" || $_POST['paket']=="") {
			echo '<script language="javascript">
			alert ("Semua kolom harus diisi!");
			window.location=../daftar.php";
			</script>';
		}
		else{
			include '../koneksi.php';
				$password=$_POST['password'];
				$password=md5($password);
				mysqli_query($koneksi,"UPDATE user SET email='$_POST[email]', pass='$password' where id_user=$id");
				mysqli_query($koneksi,"UPDATE murid SET nama='$nama', usia='$usia', no_hp='$no_hp', alamat='$alamat', paket='$paket' where id_user=$id");
				echo '<script language="javascript">
				alert ("Edit Data berhasil Di Lakukan!");
				window.location="../nyobamenu.php";
				</script>';
				exit();
		}

 ?>