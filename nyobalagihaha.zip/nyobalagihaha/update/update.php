<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Pendaftaran</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<!-- MATERIAL DESIGN ICONIC FONT -->
	<link rel="stylesheet" href="fonts/material-design-iconic-font/css/material-design-iconic-font.min.css">

	<!-- STYLE CSS -->
<!-- 	<link rel="stylesheet" href="css/main.css"> -->
	<link rel="stylesheet" type="text/css" href="../bootstrap4/css/bootstrap.min.css">
</head>

<body>
	<?php 
	$id=$_GET['id'];
	include '../koneksi.php';
	$sql=mysqli_query($koneksi,"SELECT murid.id_user,email,password,nama,usia,no_hp,alamat,paket,verifikasi from murid inner join user on murid.id_user=user.id_user where murid.id_user='$id'");
	$data=mysqli_fetch_object($sql);
	?>
	<div class="wrapper p-5 m-auto container">
		<div class="form-inner">
			<form method="post" action="update_proses.php">
				<div class="form-header">
					<h3>Update Data</h3>
					<img src="images/sign-up.png" alt="" class="sign-up-icon">
				</div>
				<div class="form-group">
					<input type="hidden" class="form-control" name="id" value="<?= $id?>">
				</div>
				<div class="form-group">
					<label for="">E-mail:</label>
					<input type="text" class="form-control" data-validation="email" name="email" value="<?= $data->email?>">
				</div>
				<div class="form-group" >
					<label for="">Password:</label>
					<input type="password" class="form-control" data-validation="length" data-validation-length="min8" name="password" value="">
				</div>
				<div class="form-group">
					<label for="">Nama :</label>
					<input type="text" class="form-control" data-validation="nama" name="nama" value="<?= $data->nama?>">
				</div>
				<div class="form-group" >
					<label for="">Usia:</label>
					<input type="text" class="form-control" name="usia" value="<?= $data->usia?>">
				</div>
				<div class="form-group" >
					<label for="">Nomor HP:</label>
					<input type="text" class="form-control" name="no_hp" value="<?= $data->no_hp?>">
				</div>
				<div class="form-group" >
					<label for="">Alamat:</label>
					<input type="text" class="form-control" name="alamat" value="<?= $data->alamat?>">
				</div>
				<div class="form-check">
					<label for="">Paket:</label> <br>
					<input type="radio" class="" name="paket" value="Shining" <?= $data->paket=='Shinnng'?"checked":'';  ?>>Shining <br>
					<input type="radio" class="" name="paket" value="Shimmering" <?= $data->paket=='Shimmering'?"checked":"";  ?>>Shimmering<br>
					<input type="radio" class="" name="paket" value="Splendid" <?= $data->paket=='Splendid'?"checked":'';  ?>>Splendid<br>
				</div>
				<button class="mt-2 btn btn-success" name="update">Update</button>
			</form>
		</div>

	</div>
	<script src="js/jquery-3.3.1.min.js"></script>
	<script src="js/jquery.form-validator.min.js"></script>
	<script src="js/main.js"></script>
</body><!-- This templates was made by Colorlib (https://colorlib.com) -->
</html>