<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Menu</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts2.googleapis.com/css?family=Roboto+Mono" rel="stylesheet">
    <link rel="stylesheet" href="fonts2/icomoon/style.css">
    <link rel="stylesheet" href="css2/bootstrap.min.css">
    <link rel="stylesheet" href="css2/magnific-popup.css">
    <link rel="stylesheet" href="css2/jquery-ui.css">
    <link rel="stylesheet" href="css2/owl.carousel.min.css">
    <link rel="stylesheet" href="css2/owl.theme.default.min.css">
    <link rel="stylesheet" href="css2/bootstrap-datepicker.css">
    <link rel="stylesheet" href="fonts2/flaticon/font/flaticon.css">
    <link rel="stylesheet" href="css2/aos.css">
    <link rel="stylesheet" href="css2/style.css">
  </head>
  <body>
    <?php 
  include 'koneksi.php';
  session_start();
  include 'cek_session.php';
  $sql=mysqli_query($koneksi,"SELECT * from murid where id_user='$_SESSION[id_user]'");
  $data=mysqli_fetch_object($sql);
  ?>

<?php 
    if($data->verifikasi==0){
?>
  <div class="site-wrap">

    <div class="site-mobile-menu">
      <div class="site-mobile-menu-header">
        <div class="site-mobile-menu-close mt-3">
          <span class="icon-close2 js-menu-toggle"></span>
        </div>
      </div>
      <div class="site-mobile-menu-body"></div>
    </div>
    
    <header class="site-navbar py-3" role="banner">
      <div class="container-fluid">
        <div class="row align-items-center">
          <div class="col-11 col-xl-2">
            <h1 class="mb-0"><a href="#" class="text-white h2 mb-0">La<span class="text-primary">Musique</span> </a></h1>
          </div>
          <div class="col-12 col-md-10 d-none d-xl-block">
            <nav class="site-navigation position-relative text-right" role="navigation">
              <ul class="site-menu js-clone-nav mx-auto d-none d-lg-block">
                <li class="cta"><a href="logout.php">Logout</a></li>
              </ul>
            </nav>
          </div>
          <div class="d-inline-block d-xl-none ml-md-0 mr-auto py-3" style="position: relative; top: 3px;"><a href="#" class="site-menu-toggle js-menu-toggle text-white"><span class="icon-menu h3"></span></a></div>
          </div>
        </div>
      </div>
    </header>

    <div class="site-section site-hero">
      <div class="container">
        <div class="row align-items-center">
          <div class="col-md-10">
            <span class="d-block mb-3 caption" data-aos="fade-up" data-aos-delay="100">----------</span>
            <h1 class="d-block mb-4" data-aos="fade-up" data-aos-delay="200">Silahkan Tunggu Akun Anda Diverifikasi oleh Admin</h1>
            <div class="loader"></div>
            <span class="d-block mb-5 caption" data-aos="fade-up" data-aos-delay="300">----------</span>
          </div>
        </div>
      </div>
    </div>
<?php
        }
        else{
?>
 <div class="site-wrap">

    <div class="site-mobile-menu">
      <div class="site-mobile-menu-header">
        <div class="site-mobile-menu-close mt-3">
          <span class="icon-close2 js-menu-toggle"></span>
        </div>
      </div>
      <div class="site-mobile-menu-body"></div>
    </div>
    
    <header class="site-navbar py-3" role="banner">
      <div class="container-fluid">
        <div class="row align-items-center">
          <div class="col-11 col-xl-2">
            <h1 class="mb-0"><a href="index.php" class="text-white h2 mb-0">La<span class="text-primary">Musique</span> </a></h1>
          </div>
          <div class="col-12 col-md-10 d-none d-xl-block">
            <nav class="site-navigation position-relative text-right" role="navigation">
              <ul class="site-menu js-clone-nav mx-auto d-none d-lg-block">
                <li class="active"><a href="index.html">Home</a></li>
                <li><a href="update/update.php?id=<?= $data->id_user ?>">Ganti Data</a></li>
                <li class="cta"><a href="logout.php">Logout</a></li>
              </ul>
            </nav>
          </div>
          <div class="d-inline-block d-xl-none ml-md-0 mr-auto py-3" style="position: relative; top: 3px;"><a href="#" class="site-menu-toggle js-menu-toggle text-white"><span class="icon-menu h3"></span></a></div>
          </div>
        </div>
      </div>
    </header>

    <div class="site-section site-hero">
      <div class="container">
        <div class="row align-items-center">
          <div class="col-md-10">
            <span class="d-block mb-3 caption" data-aos="fade-up" data-aos-delay="100">Selamat Datang,</span>
            <h1 class="d-block mb-4" data-aos="fade-up" data-aos-delay="100"><?php echo "$_SESSION[nama]"; ?></h1>
            <span class="d-block mb-5 caption" data-aos="fade-up" data-aos-delay="300"><?php echo "$data->usia, $data->no_hp, $data->alamat, $data->paket"; ?></span>
            <a href="update/update.php?id=<?= $data->id_user ?>" class="btn-custom" data-aos="fade-up" data-aos-delay="400"><span>Ganti Data</span></a>
          </div>
        </div>
      </div>
    </div>
  </div>

      <div class="site-section">
      <div class="container">
        <div class="row mb-5">
          <div class="col-lg-4" data-aos="fade-up" data-aos-delay="100">
            <div class="site-section-heading">
              <h2>Pengajar</h2>
            </div>
          </div>
          <div class="col-lg-5 mt-5 pl-lg-5" data-aos="fade-up" data-aos-delay="200">
            <p>Dengan pengajar yang ahli pada bidangnya masing-masing kami memberikan layanan terbaik bagi orang-orang yang ingin belajar ataupun mendalami bidang musik.</p>
          </div>
        </div>

        <div class="row align-items-center speaker">
          <div class="col-lg-6 mb-5 mb-lg-0" data-aos="fade" data-aos-delay="100">
            <img src="img/jkguru.jpg" alt="Image" class="img-fluid">
          </div>
          <div class="col-lg-6 ml-auto">
            <h2 class="text-white mb-4 name" data-aos="fade-right" data-aos-delay="200">Yudhistira Bramantyo</h2>
            <div class="bio pl-lg-5">
              <span class="text-uppercase text-primary d-block mb-3" data-aos="fade-right" data-aos-delay="300">Guitar Expert</span>
              <p class="mb-4" data-aos="fade-right" data-aos-delay="400">Menyukai musik sejak kecil dan sudah memproduseri lagu sejak ia berusia 17 tahun. Dengan pengalaman yang ia punya, Yudhistira menjadi salah satu pengajar terbaik di la musique</p>
              <p data-aos="fade-right" data-aos-delay="500">
                Follow Yudhis &mdash;
                <a href="https://www.instagram.com/bts.bighitofficial" target="_blank" class="p-2"><span class="icon-instagram"></span></a>
                <a href="https://twitter.com/bts_twt" target="_blank" class="p-2"><span class="icon-twitter"></span></a>
              </p>
            </div>
          </div>
        </div>

        <div class="row align-items-center speaker">
          <div class="col-lg-6 mb-5 mb-lg-0 order-lg-2" data-aos="fade" data-aos-delay="100">
            <img src="img/seulgiguru2.jpg" alt="Image" class="img-fluid">
          </div>
          <div class="col-lg-6 ml-auto order-lg-1">
            <h2 class="text-white mb-4 name" data-aos="fade-left" data-aos-delay="200">Vebrianne Imelda</h2>
            <div class="bio pr-lg-5">
              <span class="text-uppercase text-primary d-block mb-3" data-aos="fade-left" data-aos-delay="300">Drum Expert</span>
              <p class="mb-4" data-aos="fade-left" data-aos-delay="400">Sedang menjalani pendidikan di Oxford pada bidang "Art Music" dan saat ini ia sedang menjalani tugas akhir masa perkuliahannya. Di sela-sela kesibukannya dia membuat band bersama teman-temannya untuk melepas penatnya dalam mengerjakan tugas akhir. </p>
              <p data-aos="fade-left" data-aos-delay="500">
                Follow Vebri &mdash;
                <a href="https://www.instagram.com/hi_sseulgi" target="_blank" class="p-2"><span class="icon-instagram"></span></a>
                <a href="https://twitter.com/rvsmtown" target="_blank" class="p-2"><span class="icon-twitter"></span></a>
              </p>
            </div>
          </div>
        </div>

        <div class="row align-items-center speaker">
          <div class="col-lg-6 mb-5 mb-lg-0" data-aos="fade" data-aos-delay="100">
            <img src="img/kai.jpg" alt="Image" class="img-fluid">
          </div>
          <div class="col-lg-6 ml-auto">
            <h2 class="text-white mb-4 name" data-aos="fade-right" data-aos-delay="200">Kai Kamal</h2>
            <div class="bio pl-lg-5">
              <span class="text-uppercase text-primary d-block mb-3" data-aos="fade-right" data-aos-delay="300">Piano Expert</span>
              <p class="mb-4" data-aos="fade-right" data-aos-delay="400">Sudah mempelajari musik sejak bangku sekolah dasar. Kini sedang menempuh pendidikan Instrument di Harvard University. Saat ini ia aktif mengajar di La musique dan menjadi salah satu guru terbaik</p>
              <p data-aos="fade-right" data-aos-delay="500">
                Follow Kai &mdash;
                <a href="https://www.instagram.com/txt_bighit" target="_blank" class="p-2"><span class="icon-instagram"></span></a>
                <a href="https://twitter.com/txt_members" target="_blank" class="p-2"><span class="icon-twitter"></span></a>
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
    <?php
  }
  ?>

<script src="js2/jquery-3.3.1.min.js"></script>
  <script src="js2/jquery-migrate-3.0.1.min.js"></script>
  <script src="js2/jquery-ui.js"></script>
  <script src="js2/popper.min.js"></script>
  <script src="js2/bootstrap.min.js"></script>
  <script src="js2/owl.carousel.min.js"></script>
  <script src="js2/jquery.stellar.min.js"></script>
  <script src="js2/jquery.countdown.min.js"></script>
  <script src="js2/jquery.magnific-popup.min.js"></script>
  <script src="js2/bootstrap-datepicker.min.js"></script>
  <script src="js2/aos.js"></script>
  <script src="js2/main.js"></script>
  </body>
  </html>